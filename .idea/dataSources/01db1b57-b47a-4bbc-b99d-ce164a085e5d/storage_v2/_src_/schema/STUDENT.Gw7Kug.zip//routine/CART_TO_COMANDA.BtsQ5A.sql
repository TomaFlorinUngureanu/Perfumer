create FUNCTION cart_to_comanda(p_email varchar2)
return varchar2 as
mesaj varchar2(400) := 'Succes!';
p_id int;
BEGIN
select max(id)+1 into p_id from comenzi;
FOR std_linie in (select * from shoppingCart where email=p_email) LOOP
 INSERT INTO comenzi values(p_id,std_linie.id_parfum,p_email,std_linie.cantitate,std_linie.cost,sysdate,'in curs de livrare');
END LOOP;
 DELETE FROM shoppingCart where email=p_email;
return mesaj;
END;
/

