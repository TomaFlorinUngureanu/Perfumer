create FUNCTION info_utilizator(p_email IN varchar2)
RETURN VARCHAR2 AS
v_info_utilizator varchar2(300) := '';
BEGIN
  select 'id='||ID||';nume='||NUME||';prenume='||PRENUME||';parola='||PAROLA||';email='||email into v_info_utilizator from utilizatori natural join emails where email like p_email;
  return v_info_utilizator;
END;
/

