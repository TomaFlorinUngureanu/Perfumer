create PROCEDURE adaugare_nota(p_id_utilizator IN varchar2, p_id_film IN varchar2, p_valoare IN integer, p_rezultat OUT varchar2)
as
  v_id_max integer;
  v_test integer;
BEGIN
  select max(id)+1 into v_id_max from notee;
  select count(*) into v_test from notee where id_utilizator=p_id_utilizator and id_film=p_id_film;
  IF(v_test>0)
  THEN
  p_rezultat := 'Eroare: Utilizatorul are deja filmul in lista';
  ELSE
  insert into notee values(v_id_max,p_id_utilizator,p_id_film,p_valoare);
  p_rezultat := 'Succes: Nota adaugata.';
  END IF;
END;
/

