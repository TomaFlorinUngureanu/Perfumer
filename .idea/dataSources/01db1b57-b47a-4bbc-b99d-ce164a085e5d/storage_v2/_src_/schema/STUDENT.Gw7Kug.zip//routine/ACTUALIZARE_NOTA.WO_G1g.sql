create PROCEDURE actualizare_nota(p_id_utilizator IN varchar2, p_id_film IN varchar2, p_valoare IN integer, p_rezultat OUT varchar2)
as
BEGIN
  update notee set valoare=p_valoare where id_utilizator=p_id_utilizator and id_film=p_id_film;
  p_rezultat := 'Succes: Nota a fost actualizata.';
END;
/

