create FUNCTION getAllBrands
RETURN  SYS_REFCURSOR AS
my_cursor SYS_REFCURSOR;
BEGIN
  OPEN my_cursor FOR select brand from parfumuri group by brand order by count(brand)/4 desc;
  return my_cursor;
END;
/

