create FUNCTION getAllNotes
RETURN  SYS_REFCURSOR AS
my_cursor SYS_REFCURSOR;
BEGIN
  OPEN my_cursor FOR SELECT distinct brand FROM parfumuri order by brand asc;
  return my_cursor;
END;
/

